cd ./../../build/bin/

timeout 1000 ./syft4fond -d ./../../Benchmarks/Elevators/domain.pddl -p ./../../Benchmarks/Elevators/p01.pddl -o ./../../Benchmarks/Elevators/results.csv
timeout 1000 ./syft4fond -d ./../../Benchmarks/Elevators/domain.pddl -p ./../../Benchmarks/Elevators/p02.pddl -o ./../../Benchmarks/Elevators/results.csv
timeout 1000 ./syft4fond -d ./../../Benchmarks/Elevators/domain.pddl -p ./../../Benchmarks/Elevators/p03.pddl -o ./../../Benchmarks/Elevators/results.csv
timeout 1000 ./syft4fond -d ./../../Benchmarks/Elevators/domain.pddl -p ./../../Benchmarks/Elevators/p04.pddl -o ./../../Benchmarks/Elevators/results.csv
timeout 1000 ./syft4fond -d ./../../Benchmarks/Elevators/domain.pddl -p ./../../Benchmarks/Elevators/p05.pddl -o ./../../Benchmarks/Elevators/results.csv
timeout 1000 ./syft4fond -d ./../../Benchmarks/Elevators/domain.pddl -p ./../../Benchmarks/Elevators/p06.pddl -o ./../../Benchmarks/Elevators/results.csv
timeout 1000 ./syft4fond -d ./../../Benchmarks/Elevators/domain.pddl -p ./../../Benchmarks/Elevators/p07.pddl -o ./../../Benchmarks/Elevators/results.csv
timeout 1000 ./syft4fond -d ./../../Benchmarks/Elevators/domain.pddl -p ./../../Benchmarks/Elevators/p08.pddl -o ./../../Benchmarks/Elevators/results.csv
timeout 1000 ./syft4fond -d ./../../Benchmarks/Elevators/domain.pddl -p ./../../Benchmarks/Elevators/p09.pddl -o ./../../Benchmarks/Elevators/results.csv
timeout 1000 ./syft4fond -d ./../../Benchmarks/Elevators/domain.pddl -p ./../../Benchmarks/Elevators/p10.pddl -o ./../../Benchmarks/Elevators/results.csv
timeout 1000 ./syft4fond -d ./../../Benchmarks/Elevators/domain.pddl -p ./../../Benchmarks/Elevators/p11.pddl -o ./../../Benchmarks/Elevators/results.csv
timeout 1000 ./syft4fond -d ./../../Benchmarks/Elevators/domain.pddl -p ./../../Benchmarks/Elevators/p12.pddl -o ./../../Benchmarks/Elevators/results.csv
timeout 1000 ./syft4fond -d ./../../Benchmarks/Elevators/domain.pddl -p ./../../Benchmarks/Elevators/p13.pddl -o ./../../Benchmarks/Elevators/results.csv
timeout 1000 ./syft4fond -d ./../../Benchmarks/Elevators/domain.pddl -p ./../../Benchmarks/Elevators/p14.pddl -o ./../../Benchmarks/Elevators/results.csv
timeout 1000 ./syft4fond -d ./../../Benchmarks/Elevators/domain.pddl -p ./../../Benchmarks/Elevators/p15.pddl -o ./../../Benchmarks/Elevators/results.csv