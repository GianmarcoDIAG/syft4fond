cd ./../../build/bin/

timeout 1000 ./pddl2dfa -d ./../../Benchmarks/RectangleTireworld/domain-rectangle-tire.pddl -p ./../../Benchmarks/RectangleTireworld/p1.pddl -o ./../../Benchmarks/RectangleTireworld/dfa-results.csv -a 1 ;
timeout 1000 ./pddl2dfa -d ./../../Benchmarks/RectangleTireworld/domain-rectangle-tire.pddl -p ./../../Benchmarks/RectangleTireworld/p2.pddl -o ./../../Benchmarks/RectangleTireworld/dfa-results.csv -a 1 ;
timeout 1000 ./pddl2dfa -d ./../../Benchmarks/RectangleTireworld/domain-rectangle-tire.pddl -p ./../../Benchmarks/RectangleTireworld/p3.pddl -o ./../../Benchmarks/RectangleTireworld/dfa-results.csv -a 1 ;
timeout 1000 ./pddl2dfa -d ./../../Benchmarks/RectangleTireworld/domain-rectangle-tire.pddl -p ./../../Benchmarks/RectangleTireworld/p4.pddl -o ./../../Benchmarks/RectangleTireworld/dfa-results.csv -a 1 ;
timeout 1000 ./pddl2dfa -d ./../../Benchmarks/RectangleTireworld/domain-rectangle-tire.pddl -p ./../../Benchmarks/RectangleTireworld/p5.pddl -o ./../../Benchmarks/RectangleTireworld/dfa-results.csv -a 1 ;
timeout 1000 ./pddl2dfa -d ./../../Benchmarks/RectangleTireworld/domain-rectangle-tire.pddl -p ./../../Benchmarks/RectangleTireworld/p6.pddl -o ./../../Benchmarks/RectangleTireworld/dfa-results.csv -a 1 ;
timeout 1000 ./pddl2dfa -d ./../../Benchmarks/RectangleTireworld/domain-rectangle-tire.pddl -p ./../../Benchmarks/RectangleTireworld/p7.pddl -o ./../../Benchmarks/RectangleTireworld/dfa-results.csv -a 1 ;
timeout 1000 ./pddl2dfa -d ./../../Benchmarks/RectangleTireworld/domain-rectangle-tire.pddl -p ./../../Benchmarks/RectangleTireworld/p8.pddl -o ./../../Benchmarks/RectangleTireworld/dfa-results.csv -a 1 ;
timeout 1000 ./pddl2dfa -d ./../../Benchmarks/RectangleTireworld/domain-rectangle-tire.pddl -p ./../../Benchmarks/RectangleTireworld/p9.pddl -o ./../../Benchmarks/RectangleTireworld/dfa-results.csv -a 1 ;
timeout 1000 ./pddl2dfa -d ./../../Benchmarks/RectangleTireworld/domain-rectangle-tire.pddl -p ./../../Benchmarks/RectangleTireworld/p10.pddl -o ./../../Benchmarks/RectangleTireworld/dfa-results.csv -a 1 ;
timeout 1000 ./pddl2dfa -d ./../../Benchmarks/RectangleTireworld/domain-rectangle-tire.pddl -p ./../../Benchmarks/RectangleTireworld/p11.pddl -o ./../../Benchmarks/RectangleTireworld/dfa-results.csv -a 1 ;
timeout 1000 ./pddl2dfa -d ./../../Benchmarks/RectangleTireworld/domain-rectangle-tire.pddl -p ./../../Benchmarks/RectangleTireworld/p12.pddl -o ./../../Benchmarks/RectangleTireworld/dfa-results.csv -a 1 ;
timeout 1000 ./pddl2dfa -d ./../../Benchmarks/RectangleTireworld/domain-rectangle-tire.pddl -p ./../../Benchmarks/RectangleTireworld/p13.pddl -o ./../../Benchmarks/RectangleTireworld/dfa-results.csv -a 1 ;
timeout 1000 ./pddl2dfa -d ./../../Benchmarks/RectangleTireworld/domain-rectangle-tire.pddl -p ./../../Benchmarks/RectangleTireworld/p14.pddl -o ./../../Benchmarks/RectangleTireworld/dfa-results.csv -a 1 ;
timeout 1000 ./pddl2dfa -d ./../../Benchmarks/RectangleTireworld/domain-rectangle-tire.pddl -p ./../../Benchmarks/RectangleTireworld/p15.pddl -o ./../../Benchmarks/RectangleTireworld/dfa-results.csv -a 1 ;