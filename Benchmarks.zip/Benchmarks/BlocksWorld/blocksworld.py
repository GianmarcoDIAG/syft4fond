def get_benchmark(b):
    header = "define (problem bw_" +str(b)+"_"+str(b)+")\n"
    domain = "(:domain blocks-domain)\n"
    objects = "(:objects "
    for i in range(1, b+1):
        objects += "b" + str(i) + " "
    objects += "- block)\n"
    init = "(:init (emptyhand) (clear b1) "
    for i in range(1, b):
        init += "(on b" + str(i) + " b" + str(i+1)+ ") "
    init += "(on-table b"+str(b)+"))\n"
    goal = "(:goal (and "
    for i in range(1, b+1):
        goal += "(on-table b"+str(i)+") (clear b"+str(i)+") "
    goal += "(emptyhand)))\n"
    return "(" + header + domain + objects + init + goal + ")"

if __name__ == "__main__":
    BENCHMARKS = 50
    for i in range(1, BENCHMARKS+1):
        out_file = open("p"+str(i)+".pddl", "w")
        out_file.write(get_benchmark(i))
        out_file.close()